import React, { useContext, useEffect, useMemo, useState } from "react";
import { useNavigate, useLocation } from 'react-router-dom';
import { TextField, Autocomplete, Box, Button } from "@mui/material";
import { accountService } from "../../services";

import UserContext from "../../shared/UserContext";
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import dayjs from 'dayjs';
import PageHeader from "../../components/PageHeader";
import { Search } from "@mui/icons-material";


const DayAccountEoD = () => {
    const location = useLocation();
    const { shopList } = useContext(UserContext);


    const receivedData = location.state && location.state.data;
    const [shopID, setShopID] = useState(null);
    const [shopCode, setShopCode] = useState(null);
    const [shopName, setShopName] = useState(null);
    const [accountDate, setAccountDate] = useState(null);

    const [shopSales, setshopSales] = useState(0);
    const [shopWin, setShopWin] = useState(0);

    const [submissionStatus, setSubmissionStatus] = useState('');
    const [submittedBy, setSubmittedBy] = useState('');

    const [submittedOn, setSubmittedOn] = useState(null);

    const [approvedBy, setApprovedBy] = useState('');
    const [approvedOn, setApprovedOn] = useState(null);


    const [accountHeadData, setAccountHeadData] = useState(null);

    const [recvdData, setRecvdData] = useState(false);

    const navigate = useNavigate();
    useEffect(() => {
        if (receivedData != null) {
            setShopID(receivedData.shopID);
            setAccountDate(receivedData.accountDate ? dayjs(receivedData.accountDate) : null);
            //getAccountHeadData();
            getShopEodData(receivedData.shopID, dayjs(receivedData.accountDate).format("YYYY-MM-DD"));
            setRecvdData(null);
        }
    }, [receivedData]);

    const getShopEodData = (_shopID, _accountDate) => {
        let postData = { 'shopID': _shopID, 'accountDate': _accountDate }
        setAccountHeadData(null);
        accountService.getShopEodData(postData).then(shopData => {
            setAccountHeadData(shopData);
            setShopID(shopData.shopID);
            setAccountDate(shopData.accountDate ? dayjs(shopData.accountDate).format("YYYY-MM-DD") : null);
            setShopCode(shopData.shopCode);
            setShopName(shopData.shopName);
            setSubmissionStatus(shopData.statusName)
            setSubmittedBy(shopData.submittedBy);
            setApprovedBy(shopData.approvedBy);
            setSubmittedOn(shopData.submittedOn);
            setApprovedOn(shopData.approvedOn);
            setshopSales(shopData.salesAmount);
            setShopWin(shopData.winningAmount);
        }).catch(err => {
            console.log('Something went wrong');
        });
    }

    //const [activeTab, setActiveTab] = useState(0);
    return (        
            <PageHeader title="Manage Shop Account">
                <LocalizationProvider dateAdapter={AdapterDayjs} >
                    <DemoContainer components={['DatePicker']} sx={{ maxWidth: 200, margin: 1, marginRight: '8px', paddingBottom: '8px', marginLeft:0 }}>
                        <DatePicker
                            label="Account Date"
                            format='DD/MM/YYYY'
                            value={accountDate}
                            disableFuture
                            sx={{ maxWidth: 200, margin: 1 }}
                            onChange={(newValue) => setAccountDate(newValue)}
                            slotProps={{ textField: { size: 'small' } }}
                        />
                    </DemoContainer>
                </LocalizationProvider>
                <Autocomplete
                    options={shopList || []}
                    value={shopList ? shopList.filter(shop => shop.shopID == shopID)[0] : null}
                    getOptionLabel={(option) => `${option.shopCode} - ${option.shopName}`}
                    sx={{ width: 200, display:'flex', justifyContent:'center' }}
                    loading={!shopList}
                    renderInput={(params) => <TextField {...params} label="Shop" size="small" />}
                    onChange={(event, newValue) => {
                        // Handle the selected shop here
                        setShopID(newValue.shopID);
                        console.log(newValue);
                      }}
                />
                <Button variant="contained" title="View" endIcon={<Search/>} sx={{margin:1}}>View</Button>
            </PageHeader>
    )


};
export default DayAccountEoD;