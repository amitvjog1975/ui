
export const Home = () => {
    return (
        <h1>KVSRS Home Page</h1>
    )
}

