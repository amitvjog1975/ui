import React from 'react'

const currentUserSubject = new  BehaviorSubject(JSON.parse())
export const LoginObserver = () => {
  return (
    <div>LoginObserver</div>
  )
}

export default LoginObserver