﻿// PrivateRoute.js
import React from 'react';
import { Outlet, Navigate } from 'react-router-dom';

const PublicRoutes = () => {
    return (<Outlet />);
};

export default PublicRoutes;
