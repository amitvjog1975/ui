import { createContext, useEffect, useState, useContext } from "react";
import Cookies from 'js-cookie';
import { shopService } from "../services";

const UserContext = createContext();


export function UserProvider ({ children }) {
    const [userData, setUserData] = useState(null);
    const [shopList, setShopList] = useState(null);
    const [token, setToken] = useState(null);

    useEffect(() => {
        let cookieDataStr = Cookies.get("kvsrsUser");
        if (cookieDataStr !== null && cookieDataStr !== undefined && cookieDataStr !== "") {
            let userData = JSON.parse(cookieDataStr);
            setUserData(userData);
            shopService.getShopMasterList().then(result => {
                setShopList(result.data);
            })            
        }
    }, []);

    const setTokenValue = (value) => {
        setToken(value);
    }

    const updateUserData = (userData) => {
        setUserData(userData);
    }

    const handleLogout = () => {
        setUserData(null);
        setToken(null);
    }
    const updateShopList = (list) => {
        setShopList(list);
    }

    return (
        <UserContext.Provider value={{ userData, updateUserData, token, setTokenValue, handleLogout, shopList, updateShopList }}>
            {children}
        </UserContext.Provider>
    )
};

export default UserContext;
