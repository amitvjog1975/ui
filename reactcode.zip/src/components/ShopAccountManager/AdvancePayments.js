import React from 'react'

const AdvancePayments = () => {
  return (
    <div>AdvancePayments</div>
  )
}

export default AdvancePayments