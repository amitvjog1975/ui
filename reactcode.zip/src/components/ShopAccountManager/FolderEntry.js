import React from 'react'

const FolderEntry = () => {
  return (
    <div>FolderEntry</div>
  )
}

export default FolderEntry