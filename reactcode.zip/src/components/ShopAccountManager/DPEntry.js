import React from 'react'

const DPEntry = () => {
  return (
    <div>DPEntry</div>
  )
}

export default DPEntry