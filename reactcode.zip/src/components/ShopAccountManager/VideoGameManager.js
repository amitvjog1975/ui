import React from 'react'

const VideoGameManager = () => {
  return (
    <div>Video Game Manager</div>
  )
}

export default VideoGameManager