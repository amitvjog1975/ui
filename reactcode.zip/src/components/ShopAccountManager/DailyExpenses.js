import React from 'react'

const DailyExpenses = () => {
  return (
    <div>DailyExpenses</div>
  )
}

export default DailyExpenses